angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
      
        
    .state('tabsController.timeline', {
      url: '/timeline',
      views: {
        'tab1': {
          templateUrl: 'templates/timeline.html',
          controller: 'timelineCtrl'
        }
      }
    })
        
      
    
      
    .state('tabsController', {
      url: '/page3',
      abstract:true,
      templateUrl: 'templates/tabsController.html'
    })
      
    
      
        
    .state('tabsController.linkedin', {
      url: '/item-linkedin',
      views: {
        'tab1': {
          templateUrl: 'templates/linkedin.html',
          controller: 'linkedinCtrl'
        }
      }
    })
        
      
    
      
        
    .state('tabsController.tesco', {
      url: '/item_Tesco',
      views: {
        'tab1': {
          templateUrl: 'templates/tesco.html',
          controller: 'tescoCtrl'
        }
      }
    })
        
      
    
      
        
    .state('tabsController.o2', {
      url: '/item_O2',
      views: {
        'tab1': {
          templateUrl: 'templates/o2.html',
          controller: 'o2Ctrl'
        }
      }
    })
        
      
    
      
        
    .state('tabsController.lAFitness', {
      url: '/page9',
      views: {
        'tab1': {
          templateUrl: 'templates/lAFitness.html',
          controller: 'lAFitnessCtrl'
        }
      }
    })
        
      
    
      
        
    .state('tabsController.addItem', {
      url: '/page12',
      views: {
        'tab2': {
          templateUrl: 'templates/addItem.html',
          controller: 'addItemCtrl'
        }
      }
    })
        
      
    
      
        
    .state('tabsController.settings', {
      url: '/settings',
      views: {
        'tab4': {
          templateUrl: 'templates/settings.html',
          controller: 'settingsCtrl'
        }
      }
    })
        
      
    ;

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/page3/timeline');

});