angular.module('app.controllers', [])
  
.controller('timelineCtrl', function($scope) {

})
      
.controller('linkedinCtrl', function($scope) {

})
   
.controller('tescoCtrl', function($scope) {

})
   
.controller('o2Ctrl', function($scope) {

})
   
.controller('lAFitnessCtrl', function($scope) {

})
   
.controller('addItemCtrl', function($scope) {

})
   
.controller('settingsCtrl', function($scope) {

})
 